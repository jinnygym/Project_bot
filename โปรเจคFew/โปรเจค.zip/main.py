import discord
from Instagram import igclass
from Ejudge import ejudgeclass

client = discord.Client()

@client.event
async def on_ready():
    print(f"Logged in as {client.user}")

@client.event
async def on_ready(ctx, par):
    await ctx.channel.send(f"Message +>  {par}, {ctx}")

@client.event
async def on_message(message):
    global message_lastseen, message2_lastseen

    if message.content.count("!chotipat entercoruse") >= 1:
        few = message.content.split()
        ejudgeclass.entercourse()         
        await message.channel.send('```สำเร็จ```')
    if message.content.count("!chotipat findejudge") >= 1:
        few = message.content.split()
        if len(few) == 2:
            await message.channel.send('```กรุณาใส่ข้อมูลก่อนทำรายการ```')
        else:
            datauser = ejudgeclass.findejudge(few[2])
            await message.channel.send('```Status => กำลังค้นหาชื่อ```')
            if datauser['status'] == 'success':
                embed=discord.Embed(title=message.author, description="#%s" %(datauser['data']['studentid']), color=0x826868)
                embed.set_thumbnail(url="https://lh3.googleusercontent.com/proxy/Bd0au_i6rLJFx2rEo-Qnvu52PhDdD53AOSquCLujYzJMQYo4-0zsr6NVGL175iGEBr7BqO4mkXPJkJZTvQjSzCOsRbapX8ye=s0-d")
                embed.set_footer(text="กำลังค้นหาข้อมูลใน Ejudge")
                await message.channel.send(embed=embed)
            else:
                await message.channel.send('```Status => ไม่เจอชื่อผู้ใช้หรือว่าเลขนักศึกษา```')
    if message.content.count("!chotipat findproblem") >= 1:
        few = message.content.split()
        if len(few) == 3:
            await message.channel.send('```กรุณาใส่ข้อมูลก่อนทำรายการ```')
        else:
            embed = discord.Embed(title="Ejudge Search", description=message.author, color=0x13f2f2)
            embed.set_author(name = 'Welcome back homie.', icon_url = 'https://cdn.discordapp.com/emojis/786631852931940382.gif?size=64')
            embed.set_thumbnail(url = message.author.avatar_url)
            embed.set_footer(icon_url = message.author.avatar_url, text = f"Requested by {message.author}")
            await message.channel.send(embed = embed)
            datauser = ejudgeclass.golink(few[2], int(few[3]))
            embed = discord.Embed(title="Ejudge Search", description='\n'.join(str(e) for e in datauser), color=0x13f2f2)
            embed.set_author(name = 'Welcome back homie.', icon_url = 'https://cdn.discordapp.com/emojis/786631852931940382.gif?size=64')
            embed.set_footer(icon_url = message.author.avatar_url, text = f"Requested by {message.author}")
            await message.channel.send(embed = embed)
    if message.content == '!chotipat help':
        embed = discord.Embed(title=message.author, url="https://realdrewdata.medium.com/", set_author="", description="few", color=0x112244)
        await message.channel.send(embed = embed)
        await message.channel.send('```พิมคำว่า : สวัสดีครับอาจารย์โช \nเพื่อให้อาจารย์โชตอบกลับ```')
client.run('ODk1Mjk0NzU0NjM0NDY5Mzg3.YV2eNw.zB0SEomfc-X5qwyEWzVahQuR1W0')
